// WorkTrack server: serves the website + keeps ALL data in one place. No dependencies. Node 18+.
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,DIR=process.env.DATA_DIR||__dirname,FILE=path.join(DIR,'data.json');
const BK=process.env.BACKUP_URL,BKEY=process.env.BACKUP_KEY||'';
const TZ='Asia/Kolkata';
let DB,dirty=false;
const fresh=()=>({secret:crypto.randomBytes(24).toString('hex'),admins:[{user:'admin1',pass:'Admin1@Delhi26'},{user:'admin2',pass:'Admin2@Delhi26'}],workers:[],att:[],work:[],upd:[],pay:[]});
const fD=ms=>new Date(ms).toLocaleDateString('en-CA',{timeZone:TZ});
const bkUrl=()=>BK+(BK.includes('?')?'&':'?')+'key='+encodeURIComponent(BKEY);
async function init(){
  try{DB=JSON.parse(fs.readFileSync(FILE,'utf8'))}catch(e){}
  if(!DB&&BK){try{const t=await (await fetch(bkUrl())).text();const j=JSON.parse(t);if(j&&j.admins){DB=j;console.log('Restored data from Google Drive')}}catch(e){console.log('No Drive backup to restore')}}
  if(!DB)DB=fresh();
  for(const k of ['workers','att','work','upd','pay'])DB[k]=DB[k]||[];
  persist();
}
function persist(){try{fs.mkdirSync(DIR,{recursive:true});fs.writeFileSync(FILE+'.tmp',JSON.stringify(DB));fs.renameSync(FILE+'.tmp',FILE)}catch(e){console.error('save failed',e.message)}dirty=true}
setInterval(async()=>{if(!BK||!dirty)return;dirty=false;try{await fetch(bkUrl(),{method:'POST',headers:{'Content-Type':'text/plain'},body:JSON.stringify(DB)})}catch(e){dirty=true;console.error('Drive backup failed')}},60000);
const sign=p=>{const b=Buffer.from(JSON.stringify(p)).toString('base64url');return b+'.'+crypto.createHmac('sha256',DB.secret).update(b).digest('base64url')};
function verify(t){try{const[b,s]=t.split('.');const ok=crypto.createHmac('sha256',DB.secret).update(b).digest('base64url');if(s!==ok)return null;const p=JSON.parse(Buffer.from(b,'base64url'));return p.exp>Date.now()?p:null}catch(e){return null}}
const fails={};
function dataFor(a){
  if(a.role=='admin')return{admins:DB.admins.map(x=>({user:x.user})),workers:DB.workers,att:DB.att,work:DB.work,upd:DB.upd,pay:DB.pay};
  const id=a.id;return{workers:DB.workers.filter(w=>w.id==id),att:DB.att.filter(x=>x.w==id),work:DB.work.filter(k=>k.to=='all'||k.to==id),upd:DB.upd.filter(x=>x.w==id),pay:DB.pay.filter(x=>x.w==id)};
}
const str=(v,n)=>String(v==null?'':v).slice(0,n);
function cleanWorker(w){return{id:str(w.id,40),name:str(w.name,80),phone:str(w.phone,20),email:str(w.email,80),user:str(w.user,40).toLowerCase(),pass:str(w.pass,60),hours:+w.hours>0?+w.hours:8,salary:+w.salary||0,shift:w.shift=='Night'?'Night':'Day'}}
async function route(req,res,url,body){
  const J=(c,o)=>{res.writeHead(c,{'Content-Type':'application/json'});res.end(JSON.stringify(o))};
  const m=req.method,p=url.pathname;
  if(p=='/api/login'&&m=='POST'){
    const ip=req.socket.remoteAddress,f=fails[ip]||{n:0,t:Date.now()};if(Date.now()-f.t>6e5){f.n=0;f.t=Date.now()}
    if(f.n>=10)return J(429,{error:'Too many attempts. Wait 10 minutes.'});
    const u=str(body.u,80).trim().toLowerCase(),pw=str(body.p,60);let a=null;
    const ad=DB.admins.find(x=>x.user==u&&x.pass==pw);
    if(ad)a={role:'admin',id:ad.user};else{const w=DB.workers.find(x=>[x.user,x.phone,x.email].some(v=>v&&String(v).toLowerCase()==u)&&x.pass==pw);if(w)a={role:'worker',id:w.id}}
    if(!a){f.n++;fails[ip]=f;return J(401,{error:'Wrong username or password'})}
    return J(200,{token:sign({...a,exp:Date.now()+30*864e5})});
  }
  const au=verify((req.headers.authorization||'').replace('Bearer ',''));
  if(!au)return J(401,{error:'Please login again'});
  if(au.role=='worker'&&!DB.workers.some(w=>w.id==au.id))return J(401,{error:'Account removed'});
  if(p=='/api/data'&&m=='GET')return J(200,{role:au.role,id:au.id,data:dataFor(au)});
  if(au.role=='worker'){
    const w=DB.workers.find(x=>x.id==au.id);
    if(p=='/api/punch'&&m=='POST'){const n=Date.now(),o=DB.att.find(a=>a.w==w.id&&!a.out);
      const loc=Array.isArray(body.loc)&&body.loc.length==2?[+body.loc[0],+body.loc[1]]:null;
      if(o){o.out=n;o.oloc=loc;o.hrs=(n-o.in)/36e5;o.ot=Math.max(0,o.hrs-w.hours)}
      else DB.att.push({id:crypto.randomUUID(),w:w.id,date:fD(n),in:n,iloc:loc,shift:body.shift=='Night'?'Night':'Day',hrs:0,ot:0});
      persist();return J(200,{ok:1});}
    if(p=='/api/update'&&m=='POST'){const u={id:crypto.randomUUID(),w:w.id,date:fD(Date.now()),text:str(body.text,3000),stock:str(body.stock,500),img:str(body.img,900000),aud:str(body.aud,6000000)};
      if(u.img&&!u.img.startsWith('data:image/'))u.img='';if(u.aud&&!u.aud.startsWith('data:audio/'))u.aud='';
      DB.upd.push(u);persist();return J(200,{ok:1});}
    return J(403,{error:'Admin only'});
  }
  if(p=='/api/save'&&m=='POST'){
    if(!Array.isArray(body.workers)||!Array.isArray(body.work)||!Array.isArray(body.pay))return J(400,{error:'Bad data'});
    const ws=body.workers.map(cleanWorker),seen=new Set(DB.admins.map(a=>a.user));
    for(const w of ws){if(!w.id||!w.name||!w.user||!w.pass)return J(400,{error:'Worker needs name, username, password'});if(seen.has(w.user))return J(400,{error:'Username already used: '+w.user});seen.add(w.user)}
    DB.workers=ws;
    DB.work=body.work.map(k=>({id:str(k.id,40),to:str(k.to,40),date:str(k.date,10),text:str(k.text,3000)}));
    DB.pay=body.pay.map(x=>({id:str(x.id,40),w:str(x.w,40),month:str(x.month,7),type:x.type=='advance'?'advance':'salary',amt:+x.amt||0,date:str(x.date,10)}));
    persist();return J(200,{ok:1});}
  if(p=='/api/adminpw'&&m=='POST'){const a=DB.admins.find(x=>x.user==body.user);if(!a||str(body.pass,60).length<6)return J(400,{error:'Min 6 characters'});a.pass=str(body.pass,60);persist();return J(200,{ok:1});}
  if(p=='/api/backup'&&m=='GET'){const{secret,...rest}=DB;return J(200,rest);}
  if(p=='/api/restore'&&m=='POST'){
    for(const k of ['workers','att','work','upd','pay'])if(!Array.isArray(body[k]))return J(400,{error:'Invalid backup'});
    for(const k of ['workers','att','work','upd','pay'])DB[k]=body[k];
    if(Array.isArray(body.admins)&&body.admins.length&&body.admins.every(a=>a.user&&a.pass))DB.admins=body.admins;
    persist();return J(200,{ok:1});}
  J(404,{error:'Not found'});
}
const server=http.createServer((req,res)=>{
  const url=new URL(req.url,'http://x');
  res.setHeader('X-Content-Type-Options','nosniff');
  if(!url.pathname.startsWith('/api/')){
    if(url.pathname=='/'||url.pathname=='/index.html'){fs.readFile(path.join(__dirname,'public','index.html'),(e,d)=>{if(e){res.writeHead(500);return res.end('Missing public/index.html')}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache'});res.end(d)});return}
    if(url.pathname=='/healthz'){res.writeHead(200);return res.end('ok')}
    res.writeHead(404);return res.end('Not found');
  }
  const ch=[];let size=0;
  req.on('data',c=>{size+=c.length;if(size>40e6){req.destroy()}else ch.push(c)});
  req.on('end',()=>{let body={};try{if(ch.length)body=JSON.parse(Buffer.concat(ch))}catch(e){res.writeHead(400);return res.end('{"error":"Bad JSON"}')}
    route(req,res,url,body).catch(e=>{console.error(e);res.writeHead(500);res.end('{"error":"Server error"}')})});
});
init().then(()=>server.listen(PORT,()=>console.log('WorkTrack on port '+PORT)));
