# WorkTrack — one website, one link, shared data

One small server serves the app AND keeps all data (workers, attendance, work, photos, voice notes, salary).
Admin and workers open the SAME link on any phone, so what the admin adds, every worker can log in with.

## Admin logins (change in Settings after first login)
- admin1 / Admin1@Delhi26
- admin2 / Admin2@Delhi26

## Deploy free in ~10 minutes (Render.com)
1. Create a free GitHub account, make a new repository, upload everything in this folder (server.js, package.json, public/).
2. On render.com: New → Web Service → connect that repository.
3. Runtime: Node. Build command: (leave empty). Start command: `node server.js`. Create the service.
4. Render gives you a link like https://worktrack-xxxx.onrender.com — share it with workers. Open it on a phone and use "Add to Home screen".

## Keep data safe (IMPORTANT on free hosting)
Free hosts erase the server's disk when it restarts. Pick ONE:
- **Google Drive backup (free):** the server saves a copy to your Google Drive every minute and restores it automatically on restart.
  1. Go to script.google.com → New project → paste the code below → change `MYSECRET` to a long random word.
  2. Deploy → New deployment → Web app → Execute as: Me, Who has access: Anyone → Deploy → copy the Web app URL.
  3. In Render → Environment, add `BACKUP_URL` = that URL and `BACKUP_KEY` = your MYSECRET word.
- **Paid persistent disk:** add a disk on Render and set environment `DATA_DIR` to its mount path (e.g. /data).
Also use Backup → "Download backup (.json)" in the admin panel now and then.

```js
const KEY='MYSECRET', FILE='worktrack-data.json';
function find(){const f=DriveApp.getFilesByName(FILE);return f.hasNext()?f.next():null}
function doPost(e){if(e.parameter.key!==KEY)return ContentService.createTextOutput('no');
  const f=find()||DriveApp.createFile(FILE,'{}');f.setContent(e.postData.contents);return ContentService.createTextOutput('ok')}
function doGet(e){if(e.parameter.key!==KEY)return ContentService.createTextOutput('');
  const f=find();return ContentService.createTextOutput(f?f.getBlob().getDataAsString():'')}
```

## Notes
- Free Render sleeps after 15 min idle; the first open takes ~30 seconds. Paid plans stay awake.
- Check-in/out times are stamped by the server in Delhi time, so a worker can't change them by editing the phone clock.
- Run on your own PC: `node server.js`, open http://localhost:3000
